g++ -o main main.cpp ThinMqtt.cpp common.cpp -lpthread
g++ -o client client.cpp common.cpp -pthread
